# frozen_string_literal: true

module SassC
  module Script
    module ValueConversion
      class Base
        def initialize(value)
          @value = value
        end
      end
    end
  end
end
