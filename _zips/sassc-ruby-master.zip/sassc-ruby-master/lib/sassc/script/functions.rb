# frozen_string_literal: true

module SassC
  module Script
    module Functions
    end
  end
end
