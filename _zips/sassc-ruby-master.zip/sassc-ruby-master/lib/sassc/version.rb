# frozen_string_literal: true

module SassC
  VERSION = "2.4.0"
end
